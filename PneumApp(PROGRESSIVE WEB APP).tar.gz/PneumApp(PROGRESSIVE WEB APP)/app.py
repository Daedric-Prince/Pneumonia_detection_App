import os
from flask import Flask, render_template, flash, redirect, url_for, session, request, logging
#from data import Articles
from flask_mysqldb import MySQL
from werkzeug.utils import secure_filename
from wtforms import Form, StringField, TextAreaField, PasswordField, validators, RadioField, SelectField,DateField,IntegerField
from flask_wtf.file import FileField, FileRequired, FileAllowed
from passlib.hash import sha256_crypt
from functools import wraps
from wtforms.validators import DataRequired, Length, Email, EqualTo, ValidationError,NumberRange

app = Flask(__name__)
app.secret_key='vi_sh'

# Config MySQL
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = '1705'
app.config['MYSQL_DB'] = 'pneumonia'
app.config['MYSQL_CURSORCLASS'] = 'DictCursor'
# init MYSQL
mysql = MySQL(app)
APP_ROOT=os.path.dirname(os.path.abspath(__file__))

#Articles = Articles()

#xrayimg = UploadSet('images', IMAGES)

# Index
@app.route('/')
def index():
    return render_template('home.html')

# About
@app.route('/about')
def about():
    return render_template('about.html')


#this is help desk
@app.route('/help')
def help():
    return render_template('help.html')

# Register Form Class
class RegisterForm(Form):
    username = StringField('Username', validators=[DataRequired(),Length(min=4, max=10)])
    email = StringField('Email', [DataRequired(),Email()])
    password = PasswordField('Password', [DataRequired(), EqualTo('confirm', message='Passwords do not match')])
    confirm = PasswordField('Confirm Password')


# User Register
@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegisterForm(request.form)
    if request.method == 'POST' and form.validate():
        email = form.email.data
        username = form.username.data
        password = sha256_crypt.encrypt(str(form.password.data))

        # Create cursor
        cur = mysql.connection.cursor()

        # Execute query
        cur.execute("INSERT INTO users(email, username, password) VALUES(%s, %s, %s)", (email, username, password))

        # Commit to DB
        mysql.connection.commit()

        # Close connection
        cur.close()

        flash('Registered successful', 'success')

        return redirect(url_for('login'))
    return render_template('register.html', form=form)


# User Profile
@app.route('/profile', methods=['GET', 'POST'])
def Profile():

    if request.method == 'POST':
        email = request.form['email']
        fname = request.form['fname']
        lname = request.form['lname']
        phone = request.form['phone']
        bgroup = request.form['bgroup']
        gender = request.form['gender']
        dob = request.form['dob']
        age = request.form['age']
        place = request.form['place']
        severe = request.form['severe']
        symptoms = request.form['symptoms']
        cpain = request.form['cpain']
        file = request.files['xray']
        status = request.form['status']
        result = request.form['result']
        
        target = os.path.join(APP_ROOT, 'XRAY_Uploads')
        if not os.path.isdir(target):
            os.makedirs(target)
        print (target)
        filename = file.filename
        destination = "/".join([target, filename])
        print (destination)
        file.save(destination)
        datafile = open(destination, "rb")
        d = open("/home/shikashi/Pictures/uploaded_XRAY/xrayimg.jpeg", "wb")
        thedata = datafile.read()
        d.write(thedata)
        d.close()
        datafile.close()
        xray = open("/home/shikashi/Pictures/uploaded_XRAY/xrayimg.jpeg", 'rb').read()

        # Create cursor
        cur = mysql.connection.cursor()

        # Execute query
        cur.execute("INSERT INTO profile(email, fname, lname, phone, bgroup, gender, dob, age, place, severe, symptoms, cpain, xray,status,result) VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,%s,%s)", (email, fname, lname, phone, bgroup, gender, dob, age, place, severe, symptoms, cpain, xray,status,result))

        # Commit to DB
        mysql.connection.commit()

        # Close connection
        cur.close()

        flash('Profile Submitted Successful', 'success')

        return redirect(url_for('thankyou'))
    return render_template('profile.html')

    

# User login
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        # Get Form Fields
        email = request.form['email']
        password_candidate = request.form['password']

        # Create cursor
        cur = mysql.connection.cursor()

        # Get user by username
        result = cur.execute("SELECT * FROM users WHERE email = %s", [email])


        if result > 0:
            # Get stored hash
            data = cur.fetchone()
            password = data['password']
            email = data['email']
            username = data['username']
            # Compare Passwords
            if sha256_crypt.verify(password_candidate, password):
                # Passed
                session['logged_in'] = True
                session['username'] = username
                session['email'] = email
                result1 = cur.execute("SELECT * FROM profile WHERE email = %s", [email])
                if result1 > 0 :
                    data = cur.fetchone()
                    lname = data['lname']
                    phone = data['phone']
                    bgroup = data['bgroup']
                    gender = data['gender']
                    dob = data['dob']
                    age = data['age']
                    place = data['place']
                    status = data['status']
                    result = data['result']


                    session['lname'] =lname
                    session['phone'] =phone
                    session['bgroup'] = bgroup
                    session['gender'] = gender
                    session['dob'] =dob
                    session['age'] =age
                    session['place'] =place
                    session['status'] =status
                    session['result'] = result

                    

                    return redirect(url_for('account'))

                else:
                    return redirect(url_for('Profile'))
            else:
                error = 'Invalid login'
                return render_template('login.html', error=error)
            # Close connection
            cur.close()


        else:
            error = 'User not found'
            return render_template('login.html', error=error)

    return render_template('login.html')



@app.route('/thankyou',methods=['GET', 'POST'])
def thankyou():
    if request.method == 'POST':
        # Get Form Fields
        email = request.form['email']

        # Create cursor
        cur = mysql.connection.cursor()

        # Get user by username
        result = cur.execute("SELECT * FROM profile WHERE email = %s", [email])



        if result > 0:
            data = cur.fetchone()
            lname = data['lname']
            phone = data['phone']
            bgroup = data['bgroup']
            gender = data['gender']
            dob = data['dob']
            age = data['age']
            place = data['place']
            status = data['status']
            result = data['result']


            session['lname'] =lname
            session['phone'] =phone
            session['bgroup'] = bgroup
            session['gender'] = gender
            session['dob'] =dob
            session['age'] =age
            session['place'] =place
            session['status'] =status
            session['result'] = result
            #return redirect(url_for('account'))
            # Close connection
        cur.close()

    return render_template('thankyou.html')



   

# Check if user logged in
def is_logged_in(f):
    @wraps(f)
    def wrap(*args, **kwargs):
        if 'logged_in' in session:
            return f(*args, **kwargs)
        else:
            flash('Unauthorized, Please login', 'danger')
            return redirect(url_for('login'))
    return wrap

#Account
@app.route('/account', methods=['GET', 'POST'])
def account():
    if request.method == 'POST':
        email = request.form['email']
        file = request.files['xray']
        target = os.path.join(APP_ROOT, 'XRAY_Uploads')
        if not os.path.isdir(target):
            os.makedirs(target)
        print (target)
        filename = file.filename
        destination = "/".join([target, filename])
        print (destination)
        file.save(destination)
        datafile = open(destination, "rb")
        d = open("/home/shikashi/Pictures/uploaded_XRAY/xrayimg.jpeg", "wb")
        thedata = datafile.read()
        d.write(thedata)
        d.close()
        datafile.close()
        xray = open("/home/shikashi/Pictures/uploaded_XRAY/xrayimg.jpeg", 'rb').read()

        # Create cursor
        cur = mysql.connection.cursor()

        # Execute query
        #cur.execute("INSERT INTO profile(email, fname, lname, phone, bgroup, gender, dob, age, place, severe, symptoms, cpain, xray,status,result) VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,%s,%s)", (email, fname, lname, phone, bgroup, gender, dob, age, place, severe, symptoms, cpain, xray,status,result))
        cur.execute("""
               UPDATE profile
               SET  xray=%s
               WHERE email=%s
            """, ( xray, email))
        # Commit to DB
        mysql.connection.commit()

        # Close connection
        cur.close()

        flash('Image Updated Successfully', 'success')

        return redirect(url_for('thankyou'))
    return render_template('account.html')


# Logout
@app.route('/logout')
@is_logged_in
def logout():
    session.clear()
    return redirect(url_for('login'))

#------------------------------------------------------------------------------
@app.route('/offline.html')
def offline():
    return app.send_static_file('offline.html')

@app.route('/service-worker.js')
def sw():
    return app.send_static_file('service-worker.js')
    
if __name__ == '__main__':
    app.run(debug=True)
